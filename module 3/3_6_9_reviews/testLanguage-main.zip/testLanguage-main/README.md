# testLanguage

This repository stores files required to test localization of web applications using Selenium WebDriver and pytest.

conftest.py - reads the language param from the CLI and starts the browser in the defined language.
test_items.py - implements a test that opens the product page on a website to check if it has an Add To Cart button.


